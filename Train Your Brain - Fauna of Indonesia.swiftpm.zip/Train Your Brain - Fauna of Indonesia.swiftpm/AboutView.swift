//
//  AboutView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 08/04/23.
//

import SwiftUI

struct AboutView: View {
    
    @State var textSize = 25.0
    @State var titleSize = 30.0
    @State var descSize = 25.0
    
    var body: some View {
        NavigationView {
            ZStack {
                Color("green")
                    .ignoresSafeArea()
                
                Button (action: {
                }, label: {
                    NavigationLink(destination: MenuView(musicOn: true)) {
                        HStack (alignment: .top) {
                            Image(systemName: "arrowshape.turn.up.backward.fill")
                                .resizable()
                                .frame(width: 40, height: 30)
                            Text("Back")
                                .font(.system(size: 30.7, design: .rounded))
                                .bold()
                                .padding(.horizontal, 10)
                        }
                    }
                })
                .position(x: -200, y: -500)
                .frame(width: 200, height: 20)
                
                VStack {
                    
                    Image("logo")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .padding(.vertical, 50)
                    
                    ScrollView {
                        VStack (alignment: .center){
                            
                            Text("You think your brain is functioning at it’s 100% capacity? \n\nWell.. test it out with Train Your Brain - Fauna of Indonesia\n… also you can get to know Indonesia’s beautiful faunas :D")
                                .font(.system(size: descSize, design: .rounded))
                                .bold()
                            
                            Text("About the App")
                                .font(.system(size: titleSize, design: .rounded))
                                .bold()
                                .padding(.top, 20)
                                .padding(.bottom, 10)
                            
                            Text("Train Your Brain - Fauna of Indonesia is a brain training game specially designed for people of all ages to improve their memory, while also getting to know Indonesia’s fauna. \n\nThis game can be played whenever you want to learn more about Indonesia’s fauna or just having fun, be it on your free time or when you need some refreshment to cool your brain and elevate your mood.\n\nThe app interface is optimized for iPad Pro 11-inch (4th generation).")
                                .font(.system(size: textSize, design: .rounded))
                            
                            Text("Credits")
                                .font(.system(size: titleSize, design: .rounded))
                                .bold()
                                .padding(.top, 20)
                                .padding(.bottom, 10)
                            
                            Group {
                                Text("[Babirusa Image Source](https://upload.wikimedia.org/wikipedia/commons/c/cd/Hirscheber1a.jpg)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Badak Jawa Image Source](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAUf5oi.img?w=750&h=500&m=4&q=79)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Burung Maleo Image Source](https://www.goodnewsfromindonesia.id/uploads/post/large-shutterstock-1292538034-f8bcaa95b62159ea01380ab2fd1b9c23.jpg)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Harimau Sumatera Image Source](https://upload.wikimedia.org/wikipedia/commons/e/e1/Sumatran_Tiger_Berlin_Tierpark.jpg)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Jalak Bali Image Source](https://cdn.download.ams.birds.cornell.edu/api/v1/asset/275462541/1800)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Komodo Image Source](https://whc.unesco.org/uploads/thumbs/site_0609_0015-750-750-20170222120018.jpg)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Kura-Kura Leher Ular Image Source](https://pbs.twimg.com/media/FASjRRHVIAA12NC.jpg)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Orang Utan Image Source](https://diskominfo.kaltimprov.go.id/storage/image/6dac1MZhWMiVUYvN.jpg)")
                                    .font(.system(size: textSize, design: .rounded))
    
                                Text("[Tarsius Kerdil Image Source](https://1001indonesia.net/asset/2016/03/Tarsius-tumpara-atau-Tarsius-siau.jpg)")
                                    .font(.system(size: textSize, design: .rounded))
                                
                                Text("[Background Music Source](https://mixkit.co)")
                                    .font(.system(size: textSize, design: .rounded))
                            }
                            
//                        https:/www.fontspace.com/falling-sky-font-f22358

                        }
                        .frame(width: 700, height: 700, alignment: .leading)
                        .multilineTextAlignment(.center)
                        .accentColor(.white)
                    }
                }
                .padding(.top, 100)
            }
        }
        .foregroundColor(.white)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(.stack)
    }
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
