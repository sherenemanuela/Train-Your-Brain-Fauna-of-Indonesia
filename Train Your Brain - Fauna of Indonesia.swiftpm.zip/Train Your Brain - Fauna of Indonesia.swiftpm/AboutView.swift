//
//  AboutView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 08/04/23.
//

import SwiftUI

struct AboutView: View {
    
    @State var textSize = 22.0
    @State var titleSize = 30.0
    @State var descSize = 25.0
    
    var body: some View {
        NavigationView {
            ZStack {
                Color("green")
                    .ignoresSafeArea()
                
                Button (action: {
                }, label: {
                    NavigationLink(destination: MenuView(musicOn: true)) {
                        HStack (alignment: .top) {
                            Image(systemName: "arrowshape.turn.up.backward.fill")
                                .resizable()
                                .frame(width: 40, height: 30)
                            Text("Back")
                                .font(.system(size: 30.7, design: .rounded))
                                .bold()
                                .padding(.horizontal, 10)
                        }
                    }
                })
                .position(x: -220, y: -500)
                .frame(width: 200, height: 20)
                
                VStack {
                    
                    Image("logo")
                        .resizable()
                        .frame(width: 250, height: 250)
                        .padding(.vertical, 50)
                    
                    VStack (alignment: .center){
                        
                        Text("You think your brain is functioning at it’s 100% capacity? \n\nWell.. test it out with Train Your Brain - Fauna of Indonesia\n\n… also you can get to know Indonesia’s beautiful faunas :D")
                            .font(.system(size: descSize, design: .rounded))
                            .bold()
                            .fixedSize(horizontal: false, vertical: true)
                        
                        Text("About the App")
                            .font(.system(size: titleSize, design: .rounded))
                            .bold()
                            .padding(.top, 40)
                            .padding(.bottom, 10)
                        
                        Text("Train Your Brain - Fauna of Indonesia is a brain training game specially designed for people of all ages to improve their memory, while also getting to know Indonesia’s fauna. \n\nThis game can be played whenever you want to learn more about Indonesia’s fauna or just having fun, be it on your free time or when you need some refreshment to cool your brain and elevate your mood.\n\nThe app interface is optimized for iPad Pro 11-inch (4th generation) on portrait mode.")
                            .font(.system(size: textSize, design: .rounded))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .multilineTextAlignment(.center)
                    .accentColor(.white)
                    .frame(width: 700)
                }
            }
        }
        .foregroundColor(.white)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(.stack)
    }
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
