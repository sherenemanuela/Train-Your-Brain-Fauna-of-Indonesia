//
//  SplashView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 06/04/23.
//

import SwiftUI

struct SplashView: View {
    @State private var size = 0.5
    @State private var opacity = 0.0
    @State private var textOpacity = 0.0
    @State private var isLoaded = false
    @State private var color = Color(.red)
    @State private var topOffset = 20.0
    @State private var bottomOffset = -20.0
    @State private var splashOpacity = 1.0
    
    var body: some View {
        if isLoaded {
            MenuView(musicOn: false)
        } else {
            ZStack {
                Color("green")
                    .ignoresSafeArea()
                
                VStack {
                    Text("Train Your Brain")
                        .bold()
                        .font(.system(size: 60, design: .rounded))
                        .foregroundColor(.white)
                        .offset(y: topOffset)
                        .opacity(textOpacity)
                        .onAppear {
                            withAnimation(.easeIn(duration: 1).delay(1.2)) {
                                textOpacity = 1
                                topOffset = 0
                            }
                            withAnimation(.easeIn(duration: 0.5).delay(4.0)) {
                                textOpacity = 0
                                opacity = 0
                            }
                        }
                    
                    
                    Image("logo")
                        .resizable()
                        .frame(width: 300, height: 300)
                        .scaleEffect (size)
                        .opacity (opacity)
                        .onAppear {
                            withAnimation(.easeIn(duration: 1.2)) {
                                self.opacity = 1
                                self.size = 1
                            }
                        }
                        .padding()
                        .zIndex(99)
                    
                    Text("Fauna of Indonesia")
                        .bold()
                        .font(.system(size: 40, design: .rounded))
                        .foregroundColor(.white)
                        .offset(y: bottomOffset)
                        .opacity(textOpacity)
                        .padding()
                        .onAppear {
                            withAnimation(.easeIn(duration: 1).delay(1.2)) {
                                textOpacity = 1
                                bottomOffset = 0
                            }
                        }
                }
            }
            .opacity(splashOpacity)
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    isLoaded = true
                }
            }
        }
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
    }
}
