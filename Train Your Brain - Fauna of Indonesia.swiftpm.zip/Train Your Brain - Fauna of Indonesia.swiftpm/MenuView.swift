//
//  MenuView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 07/04/23.
//

import SwiftUI

struct MenuView: View {
    
    @State var opacity = 0.0
    @State var initialLogoOffset = CGSize(width: 0, height: 185)
    @State var buttonWidth = 250.0
    @State var buttonHeight = 80.0
    @State var musicOn: Bool
    let textSize = 39.0
    
    
    init(musicOn: Bool) {
        UINavigationBar.setAnimationsEnabled(false)
        self.musicOn = musicOn
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Color("green")
                    .ignoresSafeArea()
                
                VStack {
                    Image("logo")
                        .resizable()
                        .frame(width: 300, height: 300)
                        .padding(50)
                        .offset(initialLogoOffset)
                        .onAppear {
                            withAnimation(.easeOut(duration: 1.3)) {
                                initialLogoOffset = CGSize(width: 0, height: 0)
                            }
                        }
                    
                    VStack {
                        Button {
                        } label: {
                            NavigationLink(destination: StartTimerView()) {
                                Text("Start")
                                    .font(.system(size: textSize, design: .rounded))
                                    .bold()
                                    .padding(.horizontal, 60)
                                    .padding(.vertical, 10)
                                    .frame(width: buttonWidth, height: buttonHeight)
                            }
                        }
                        .cornerRadius(100)
                        .padding(.bottom, 20)
                        
                        Button {
                        } label: {
                            NavigationLink(destination: AboutView()) {
                                Text("About")
                                    .font(.system(size: textSize, design: .rounded))
                                    .bold()
                                    .padding(20)
                                    .frame(width: buttonWidth, height: buttonHeight)
                            }
                        }
                        .cornerRadius(100)
                        .padding(.bottom, 20)
                        
                        Button {
                        } label: {
                            NavigationLink(destination: TutorialView()) {
                                Text("How to Play")
                                    .font(.system(size: textSize, design: .rounded))
                                    .bold()
                                    .padding(20)
                                    .frame(width: buttonWidth, height: buttonHeight)
                            }
                        }
                        .cornerRadius(100)
                        
                        Text("Musics from Mixkit")
                            .foregroundColor(.white)
                            .padding(.top, 20)
                    }
                    .opacity(opacity)
                    .foregroundColor(.black)
                    .buttonStyle(.borderedProminent)
                    .tint(.white)
                    .onAppear {
                        withAnimation(.easeOut(duration: 1).delay(0.8)) {
                            opacity = 1
                        }
                    }
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarBackButtonHidden(true)
        .onAppear {
            if !musicOn {
                playMusic(music: "menu_music", loop: -1)
            }
        }
    }
}

struct MenuView_Previews: PreviewProvider {
    static var previews: some View {
        MenuView(musicOn: false)
    }
}
