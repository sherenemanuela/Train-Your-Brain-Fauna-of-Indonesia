//
//  TutorialView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 08/04/23.
//

import SwiftUI

struct TutorialView: View {
    let imageSize = 400.0
    let titleFontSize = 40.0
    let descriptionFontSize = 25.0
    
    var body: some View {
        ZStack {
            Color("green")
                .ignoresSafeArea()
            
            
            Button (action: {
            }, label: {
                NavigationLink(destination: MenuView(musicOn: true)) {
                    HStack (alignment: .top) {
                        Image(systemName: "arrowshape.turn.up.backward.fill")
                            .resizable()
                            .frame(width: 40, height: 30)
                        Text("Back")
                            .font(.system(size: 30.7, design: .rounded))
                            .bold()
                            .padding(.horizontal, 10)
                    }
                }
            })
            .position(x: -200, y: -500)
            .frame(width: 200, height: 20)
            
            VStack {
                TabView {
                    VStack {
                        Text("Memorize!")
                            .font(.system(size: titleFontSize, design: .rounded))
                            .bold()
                            .padding(.bottom, 10)
                        
                        Text("You are given 10 seconds to memorize the positions of the cards")
                            .font(.system(size: descriptionFontSize, design: .rounded))
                            .padding(.bottom, 20)
                            .padding(.horizontal, 40)
                            .multilineTextAlignment(.center)
                        
                        HStack {
                            Image("tutorial_1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        .frame(width: imageSize)
                    }
                    
                    VStack {
                        Text("Guess!")
                            .font(.system(size: titleFontSize, design: .rounded))
                            .bold()
                            .padding(.bottom, 10)
                        
                        Text("One card will be flipped and you have to choose the correct card position!")
                            .font(.system(size: descriptionFontSize, design: .rounded))
                            .padding([.horizontal, .bottom], 20)
                            .padding(.horizontal, 40)
                            .multilineTextAlignment(.center)
                        
                        HStack {
                            Image("tutorial_2")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        .frame(width: imageSize)
                    }
                    
                    VStack {
                        Text("Correct Answer")
                            .font(.system(size: titleFontSize, design: .rounded))
                            .bold()
                            .padding(.bottom, 10)
                        
                        Text("Great job! The chosen fauna information will appear if you chose the correct position")
                            .font(.system(size: descriptionFontSize, design: .rounded))
                            .padding([.horizontal, .bottom], 20)
                            .padding(.horizontal, 40)
                            .multilineTextAlignment(.center)
                        
                        HStack {
                            Image("tutorial_3")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        .frame(width: imageSize)
                    }
                    
                    VStack {
                        Text("Wrong Answer")
                            .font(.system(size: titleFontSize, design: .rounded))
                            .bold()
                            .padding(.bottom, 10)
                        
                        Text("You chose the wrong position? No problem!\n You can always try again or take a break")
                            .font(.system(size: descriptionFontSize, design: .rounded))
                            .padding([.horizontal, .bottom], 20)
                            .padding(.horizontal, 40)
                            .multilineTextAlignment(.center)
                        
                        HStack {
                            Image("tutorial_4")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        .frame(width: imageSize)
                    }
                    
                    VStack {
                        Text("Good luck!")
                            .font(.system(size: 80, design: .rounded))
                            .bold()
                            .padding(.bottom, 10)
                            .multilineTextAlignment(.center)
                    }
                }
                .foregroundColor(.black)
                .background(.white)
                .cornerRadius(20)
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .frame(width: 600, height: 900)
                .padding(.top, 50)
                .onAppear {
                    UIPageControl.appearance().currentPageIndicatorTintColor = .black
                        UIPageControl.appearance().pageIndicatorTintColor = UIColor.black.withAlphaComponent(0.2)
                }
            }
        }
        .foregroundColor(.white)
        .navigationBarBackButtonHidden(true)
    }
}

struct TutorialView_Previews: PreviewProvider {
    static var previews: some View {
        TutorialView()
    }
}
