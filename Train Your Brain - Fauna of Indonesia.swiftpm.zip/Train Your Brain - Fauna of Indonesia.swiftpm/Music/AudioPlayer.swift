//
//  AudioPlayer.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 13/04/23.
//

import AVFoundation
import UIKit

var audioPlayer: AVAudioPlayer!

func playMusic(music: String, loop: Int) {
    guard let audioData = NSDataAsset(name: music)?.data else {
        fatalError("Unable to find asset \(music)")
    }
    
    do {
        audioPlayer = try AVAudioPlayer(data: audioData)
        audioPlayer.numberOfLoops = loop
        audioPlayer.play()
    } catch {
        fatalError(error.localizedDescription)
    }
}
