# Assets Attributions and Licenses

PHOTOS (CROPPED)

1. babirusa_photo by Masteraah at German Wikipedia, CC BY-SA 2.0 DE [https://creativecommons.org/licenses/by-sa/2.0/de/deed.en], via Wikimedia Commons [https://commons.wikimedia.org/wiki/File:Hirscheber1a.jpg]

2. badak_jawa_photo by Scott Nelson, CC BY 3.0 [https://creativecommons.org/licenses/by/3.0], via Wikimedia Commons [https://commons.wikimedia.org/wiki/File:Lesser_One_Horned_Rhinoceros_Rhinoceros_Sondaicus_(53549614).jpeg]

3. burung_maleo_photo by Syaiful Mooduto, CC BY-SA 4.0 [https://creativecommons.org/licenses/by-sa/4.0], via Wikimedia Common [https://commons.wikimedia.org/wiki/File:Inbound2357189318602348967.jpg]

4. harimau_sumatera_photo by NasserHalaweh, CC BY-SA 4.0 [https://creativecommons.org/licenses/by-sa/4.0], via Wikimedia Commons [https://commons.wikimedia.org/wiki/File:Felidae_Panthera_tigris_sondaica_3.jpg]

5. jalak_bali_photo by Ady Kristanto, CC BY-SA 4.0 [https://creativecommons.org/licenses/by-sa/4.0>] via Wikimedia Commons [https://commons.wikimedia.org/wiki/File:Bali_Myna_in_Bali_Barat_National_Park.jpg]

6. komodo_photo by Altraz on Unsplash [https://unsplash.com/photos/8xxwWKyDs5E]

7. kura_kura_leher_ular by Postdlf, CC BY-SA 3.0 [https://creativecommons.org/licenses/by-sa/3.0], via Wikimedia Commons [https://commons.wikimedia.org/wiki/File:Chelodina_mccordi_at_the_Columbus_Zoo-2011_07_11_IMG_0642.JPG]

8. orang_utan_photo by Carel Van Vugt on Unsplash [https://unsplash.com/photos/mc-28sbeDAs]

9. tarsius_kerdil_photo by Sakurai Midori, CC BY-SA 3.0 [http://creativecommons.org/licenses/by-sa/3.0/], via Wikimedia Commons [https://commons.wikimedia.org/wiki/File:Tarsius_tarsier_Tandurusa_zoo.JPG]


MUSICS AND SOUND EFFECTS

1. Musics by Mixkit [https://mixkit.co/free-sound-effects/], license [https://mixkit.co/license/#sfxFree]
