//
//  CardView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 07/04/23.
//

import SwiftUI

struct CardView: View {

    @State var backDegree = -90.0
    @State var frontDegree = 0.0
    @State var flipped = false
    @Binding var countdownTimer: Double
    @Binding var frameSize: Double
    @Binding var timerOn: Bool
    @Binding var animationTime: Double
    @Binding var result: Int
    @Binding var isAnswered: Bool
    let answer: Int
    let index: Int
    let cardImage: String
    
    var body: some View {
        ZStack {
            FrontCard(degree: $frontDegree, frameSize: $frameSize, image: cardImage)
            BackCard(degree: $backDegree, frameSize: $frameSize)
        }
        .onAppear {
            withAnimation(.linear(duration: animationTime).delay(countdownTimer)) {
                frontDegree = 90
            }
            withAnimation(.linear(duration: animationTime).delay(countdownTimer + animationTime)){
                backDegree = 0
            }
        }
        .onTapGesture {
            if !timerOn {
                isAnswered = true
                flipped = true
                audioPlayer.stop()
                
                withAnimation(.linear(duration: animationTime)){
                    backDegree = -90
                }
                withAnimation(.linear(duration: animationTime).delay(animationTime)) {
                    frontDegree = 0
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.7) {
                    withAnimation(.linear(duration: 0.5)) {
                        if(answer == index) {
                            result = 1
                        } else {
                            result = 2
                        }
                    }
                }
            }
        }
        .onChange(of: isAnswered) { changed in
            if changed && !flipped {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    withAnimation(.linear(duration: animationTime)){
                        backDegree = -90
                    }
                    withAnimation(.linear(duration: animationTime).delay(animationTime)) {
                        frontDegree = 0
                    }
                }
            }
        }
    }
}
