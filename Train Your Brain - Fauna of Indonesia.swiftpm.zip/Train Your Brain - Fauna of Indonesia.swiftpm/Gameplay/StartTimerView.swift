//
//  TimerView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 07/04/23.
//

import SwiftUI

struct StartTimerView: View {
    
    @State var backgroundColor = "red"
    @State var timerText = "Ready"
    @State var textColor: Color = Color(.white)
    @State var isReady = false
    
    var body: some View {
        ZStack {
            Color("\(backgroundColor)")
                .ignoresSafeArea()
            
            Text("\(timerText)")
                .bold()
                .font(.system(size: 100, design: .rounded))
                .foregroundColor(textColor)
            
            NavigationLink("", destination: GameView(), isActive: $isReady)
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            playMusic(music: "countdown_music", loop: 0)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                timerText = "Set"
                backgroundColor = "yellow"
                textColor = Color(.black)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                timerText = "Go!"
                backgroundColor = "green"
                textColor = Color(.white)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                isReady = true
            }
        }
    }
}

struct StartTimerView_Previews: PreviewProvider {
    static var previews: some View {
        StartTimerView()
    }
}
