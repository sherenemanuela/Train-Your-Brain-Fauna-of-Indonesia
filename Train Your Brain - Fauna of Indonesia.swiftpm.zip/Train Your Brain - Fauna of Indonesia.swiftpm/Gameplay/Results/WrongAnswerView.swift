//
//  WrongAnswerView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 08/04/23.
//

import SwiftUI

struct WrongAnswerView: View {
    
    @State var buttonWidth = 250.0
    @State var buttonHeight = 60.0
    
    var body: some View {
        NavigationView {
            ZStack {
                Color("red")
                    .ignoresSafeArea()
                
                VStack {
                    Text("Awww.. that's too bad!")
                        .font(.system(size: 35, design: .rounded))
                        .bold()
                        .foregroundColor(.white)
                        .padding(.bottom, 5)
                    
                    Text("You guessed incorrectly")
                        .font(.system(size: 60, design: .rounded))
                        .bold()
                        .foregroundColor(.white)
                        .padding(.bottom, 50)
                    
                    HStack {
                        Button {
                        } label: {
                            NavigationLink(destination: StartTimerView()) {
                                Text("Try Again?")
                                    .font(.system(size: 30, design: .rounded))
                                    .bold()
                                    .padding(20)
                                    .frame(width: buttonWidth, height: buttonHeight)
                            }
                        }
                        .padding(.horizontal, 30)
                        
                        Button {
                        } label: {
                            NavigationLink(destination: MenuView(musicOn: false)) {
                                Text("Take a Break")
                                    .font(.system(size: 30, design: .rounded))
                                    .bold()
                                    .padding(20)
                                    .frame(width: buttonWidth, height: buttonHeight)
                            }
                        }
                        .frame(width: buttonWidth, height: buttonHeight)
                        .padding(.horizontal, 30)
                    }
                    .foregroundColor(.black)
                    .buttonStyle(.borderedProminent)
                    .tint(.white)
                }
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
        .onAppear {
            playMusic(music: "wrong_music", loop: 0)
        }
    }
}
