//
//  CorrectAnswerView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 08/04/23.
//

import SwiftUI

struct CorrectAnswerView: View {
    
    let imageSize = 280.0
    let animal: Array<String>
    @State var resultOpacity = 1.0
    @State var animalOpacity = 0.0
    @State var buttonWidth = 230.0
    @State var buttonHeight = 60.0
    
    var body: some View {
        ZStack {
            Color("green")
                .ignoresSafeArea()
            
            VStack {
                Text("Congratulations!")
                    .font(.system(size: 60, design: .rounded))
                    .bold()
                    .padding(.bottom, 5)
                
                Text("You guessed correctly")
                    .font(.system(size: 35, design: .rounded))
                    .bold()
            }
            .opacity(resultOpacity)
            .onAppear{
                withAnimation(.linear(duration: 1).delay(1.5)) {
                    resultOpacity = 0
                    animalOpacity = 1
                }
            }
            
            VStack {
                Text("\(animal[0])")
                    .font(.system(size: 55, design: .rounded))
                    .bold()
                    .padding(.bottom, 30)
                HStack {
                    Image("\(animal[1])")
                        .resizable()
                        .frame(width: imageSize, height: imageSize)
                        .cornerRadius(20)
                    
                    Spacer()
                    
                    Image("\(animal[2])")
                        .resizable()
                        .frame(width: imageSize, height: imageSize)
                        .cornerRadius(20)
                }
                .frame(width: 600)
                
                ScrollView {
                    Text("\(animal[3])")
                        .multilineTextAlignment(.center)
                        .font(.system(size: 25, design: .rounded))
                    
                    Text("Photo © \(animal[4])")
                        .padding(.top, 20)
                }
                .frame(width: 700, height: 450)
                .padding(.vertical, 35)
                
                HStack {
                    Button {
                    } label: {
                        NavigationLink(destination: StartTimerView()) {
                            Text("Play Again?")
                                .font(.system(size: 30, design: .rounded))
                                .bold()
                                .padding(20)
                                .frame(width: buttonWidth, height: buttonHeight)
                        }
                    }
                    
                    Spacer()
                    
                    Button {
                    } label: {
                        NavigationLink(destination: MenuView(musicOn: false)) {
                            Text("Take a Break")
                                .font(.system(size: 30, design: .rounded))
                                .bold()
                                .padding(20)
                                .frame(width: buttonWidth, height: buttonHeight)
                        }
                    }
                }
                .foregroundColor(.black)
                .buttonStyle(.borderedProminent)
                .tint(.white)
                .frame(width: 550)
                .padding(.top, 10)
            }
            .opacity(animalOpacity)
            .padding()
        }
        .navigationBarBackButtonHidden(true)
        .foregroundColor(.white)
        .onAppear {
            playMusic(music: "correct_music", loop: 0)
        }
    }
}

struct CorrectAnswerView_Previews: PreviewProvider {
    static var previews: some View {
        CorrectAnswerView(animal: Data().data[0])
    }
}
