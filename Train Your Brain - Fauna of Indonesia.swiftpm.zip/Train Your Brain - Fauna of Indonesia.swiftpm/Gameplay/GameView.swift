//
//  GameView.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 07/04/23.
//

import SwiftUI

struct GameView: View {
    
    @State var isAnswered = false
    @State var result = 0
    @State var countdownTimer = 10.0
    @State var timerOn = true
    @State var instruction = "Memorize the positions"
    @State var cardSize = 200.0
    @State var cardAnimationTime = 0.3
    @State var isCorrect = false
    @State var isWrong = false
    let answer = Int.random(in: 0..<9)
    let cards = Data().data.shuffled()
    let columns = [GridItem(.adaptive(minimum: 230))]
    
    var body: some View {
        
        switch result {
        case 1:
            CorrectAnswerView(animal: cards[answer])
        case 2:
            WrongAnswerView()
        default:
            ZStack {
                Color("green")
                    .ignoresSafeArea()
                VStack {
                    Text("\(instruction)")
                        .font(.system(size: 55, design: .rounded))
                        .bold()
                        .padding(.bottom, -3)
                    
                    AnswerCardView(countdownTimer: $countdownTimer, animationTime: $cardAnimationTime, frameSize: cardSize, image: cards[answer][1])
                    
                    LazyVGrid(columns: columns, spacing: 50) {
                        ForEach(cards.indices, id: \.self) { index in
                            CardView(countdownTimer: $countdownTimer, frameSize: $cardSize, timerOn: $timerOn, animationTime: $cardAnimationTime, result: $result, isAnswered: $isAnswered, answer: answer, index: index, cardImage: cards[index][1])
                        }
                    }
                }
                .foregroundColor(.white)
                .padding(.horizontal, 50)
                .onAppear {
                    playMusic(music: "memorize_music", loop: 0)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 9.5) {
                        audioPlayer.stop()
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + countdownTimer + 1) {
                        instruction = "Where was the card?"
                        timerOn = false
                        playMusic(music: "guess_music", loop: -1)
                    }
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}
