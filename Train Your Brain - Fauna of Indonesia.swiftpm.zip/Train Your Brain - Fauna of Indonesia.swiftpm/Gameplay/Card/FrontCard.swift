//
//  SwiftUIView.swift
//  
//
//  Created by Sheren Emanuela on 07/04/23.
//

import SwiftUI

struct FrontCard: View {
    
    @Binding var degree: Double
    @Binding var frameSize: Double
    let image: String
    
    var body: some View {
        ZStack {
            Color(.white)
            
            Image("\(image)")
                .resizable()
                .padding()
        }
        .frame(width: frameSize, height: frameSize)
        .cornerRadius(20)
        .rotation3DEffect(Angle(degrees: degree), axis: (x: 0, y: 1, z: 0))
    }
}
