//
//  GameTimer.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 08/04/23.
//

import SwiftUI

struct AnswerCardView: View {
    @Binding var countdownTimer: Double
    @Binding var animationTime: Double
    @State var frontDegree = 0.0
    @State var backDegree = -90.0
    let frameSize: Double
    let image: String
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .frame(width: frameSize, height: frameSize)
                Image("\(image)")
                    .resizable()
                    .padding()
            }
            .rotation3DEffect(Angle(degrees: backDegree), axis: (x: 0, y: 1, z: 0))
            
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .frame(width: frameSize, height: frameSize)
                Text("\(Int(countdownTimer))")
                    .font(.system(size: 100, design: .rounded))
                    .foregroundColor(.black)
                    .bold()
            }
            .rotation3DEffect(Angle(degrees: frontDegree), axis: (x: 0, y: 1, z: 0))
        }
        .frame(width: frameSize, height: frameSize)
        .padding(.vertical, 30)
        .onAppear {
            withAnimation(.linear(duration: 0.3).delay(countdownTimer + 1)) {
                frontDegree = 90
            }
            withAnimation(.linear(duration: 0.3).delay(countdownTimer + 0.3 + 1)){
                backDegree = 0
            }
        }
        .onReceive(timer) { _ in
            if countdownTimer > 0 {
                countdownTimer -= 1
            } else {
                timer.upstream.connect().cancel()
            }
        }
    }
}
