//
//  BackCard.swift
//  Train Your Brain - Fauna of Indonesia
//
//  Created by Sheren Emanuela on 08/04/23.
//

import SwiftUI

struct BackCard: View {
    
    @Binding var degree: Double
    @Binding var frameSize: Double
    
    var body: some View {
        
        ZStack {
            Color(.white)
            ZStack {
                Color("cardBack")
                Image(systemName: "questionmark")
                    .foregroundColor(Color("cardBackText"))
                    .font(.system(size: 100, weight: .bold))
            }
            .cornerRadius(10)
            .frame(width: frameSize - 30, height: frameSize - 30)
        }
        .frame(width: frameSize, height: frameSize)
        .cornerRadius(20)
        .rotation3DEffect(Angle(degrees: degree), axis: (x: 0, y: 1, z: 0))
    }
}
